var elId = fragmentElement.getAttribute("id");
$("#"+elId+" table").DataTable();

function loadData(data){
    //$("#"+elId+" table").DataTable().clear();
    var length = Object.keys(data.items).length;

    for(var i = 0; i < length; i++) {
      var item = data.items[i];
			
      // You could also use an ajax property on the data table initialization
      $("#"+elId+" table").dataTable().fnAddData( [
        item.make,
        item.model,
        item.eVType,
        item.batteryRange,
        item.totalRange
      ]);
    }
}

Liferay.Util.fetch(
	configuration.apipath, {
		headers: {
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=utf8'
		},
		method: 'GET'
	}
)
	.then((response) => response.json()) 
	.then((data) => {
	//console.log("Return");
	console.log(data);
	
	loadData(data);
	
})
	.catch((error) => {
	console.log(error);
	Liferay.Util.openToast({
		message: 'An error occured.',
		type: 'danger',
	});
});